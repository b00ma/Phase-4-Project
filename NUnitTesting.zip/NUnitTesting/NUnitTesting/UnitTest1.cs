using NUnit.Framework;
using DataAccessLogicLayer;

namespace NUnitTesting
{
    public class Tests
    {
        [SetUp]
        public void Setup()
        {
        }

        [Test]
        public void Test1()
        {
            //Assign or Arrange
            int pid = 2001;
            string ptype = "Peppy Paneer";

            //Act
            string acname = PizzaHelper.GetENameById(pid);

            //Assert

            Assert.AreEqual(ptype, acname);
            Assert.Pass();
        }

        [Test]
        public void Test2()
        {
            //Assign or Arrange
            int pid = 4002;
            string ptype = "Fresh Veggie";

            //Act
            string acname = PizzaHelper.GetENameById(pid);

            //Assert

            Assert.AreEqual(ptype, acname);
            Assert.Pass();
        }

        [Test]
        public void Test3()
        {
            //Assign or Arrange
            int pid = 3001;
            string ptype = "Cheese & Corn";

            //Act
            string acname = PizzaHelper.GetENameById(pid);

            //Assert

            Assert.AreEqual(ptype, acname);
            Assert.Pass();
        }

        [Test]
        public void Test4()
        {
            //Assign or Arrange
            int pid = 5001;
            string ptype = "Peppy Paneer";

            //Act
            string acname = PizzaHelper.GetENameById(pid);

            //Assert

            Assert.AreEqual(ptype, acname);
            Assert.Pass();
        }

        [Test]
        public void Test5()
        {
            //Assign or Arrange
            int pid = 2002;
            string ptype = "Peppy Paneer";

            //Act
            string acname = PizzaHelper.GetENameById(pid);

            //Assert

            Assert.AreEqual(ptype, acname);
            Assert.Pass();
        }
    }
}